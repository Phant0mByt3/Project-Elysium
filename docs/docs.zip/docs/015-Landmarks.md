# 15 — Landmarks

Landmarks are non-quest-hub points of interest — ruins, monuments, natural wonders, and secrets — that reward exploration for its own sake, directly supporting Pillar 1 in [002-Core-Pillars.md](002-Core-Pillars.md).

## Design Rule
Every region must contain at least one landmark that is **not** required by any quest chain. Landmarks may still contain optional lore items, achievements ([074-Achievements.md](074-Achievements.md)), or hidden vendors.

## Examples

**The Sundered Spire** (Aurelia) — a half-collapsed tower jutting out of the Sunspire Hills at an impossible angle, frozen mid-fall since the Sundering. Climbing it reveals a lore journal fragment ([031-Timeline.md](031-Timeline.md)) and a hidden achievement.

**The Weeping Hollow** (Greywater Fens) — a sunken grove said to be the site of a pre-Sundering battle. At night, spectral duelists can be seen replaying their final fight.

**The Emberfall Overlook** (Vethmoor) — a cliffside view over the Ember Deeps' volcanic mines, popular as an informal player gathering and screenshot spot.

**The Cairn of Names** (Shattered Cairns) — a field of standing stones, each engraved with the name of someone lost in the Sundering; players can add commemorative names via a future community feature (see [005-Future-Plans.md](005-Future-Plans.md)).

## Categories
* **Ruins** — remnants of the Age of Concord.
* **Natural Wonders** — unique geography with no combat purpose.
* **Secrets** — hidden, unmarked locations found only through exploration or hints.
* **Memorials** — locations tied directly to lore events in [036-History.md](036-History.md).
