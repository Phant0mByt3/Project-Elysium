# 14 — Villages

Villages are smaller, lower-stakes settlements scattered through regions — rest stops, local quest hubs, and flavor locations that make the world feel lived-in outside of the capital cities.

## Purpose
Where cities ([013-Cities.md](013-Cities.md)) serve major hub functions, villages exist to:
* Anchor a region's local questline and NPCs.
* Provide a lightweight vendor and rest point without full city services.
* Give each region a distinct sense of community and culture.

## Design Requirements
* 5–15 buildings, populated with named NPCs relevant to the local story.
* At least one quest hub tied to the region's "local conflict" (see [012-Regions.md](012-Regions.md) template).
* Should feel handcrafted and distinct — no copy-pasted village kits between regions.

## Examples (Aurelia)

**Millhaven** — Southern Shires starting village where new Concord-aligned characters begin their journey; home to the tutorial questline.

**Fenwick Crossing** — a waterlogged trading post in the Greywater Fens, central to the undead-incursion questline in that region.

**Sunspire Vale** — a farming village beneath the Sunspire Hills, frequently referenced in Solmere's supply-chain quests.

Villages are cross-referenced from their parent region entries in [012-Regions.md](012-Regions.md) and should never duplicate content covered by nearby landmarks ([015-Landmarks.md](015-Landmarks.md)).
