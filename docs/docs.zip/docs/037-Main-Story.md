# 37 — Main Story

## Premise
The main campaign begins as travel between Aurelia and Vethmoor reopens for the first time since the Sundering ([036-History.md](036-History.md)). The player character is drawn into investigating why — and discovers that resurfacing Age of Concord magic is also reawakening fragments of Kaelgorath's influence.

## Act Structure

### Act I — Reconnection *(Levels 1–20, Aurelia)*
The player completes their region's local questlines (see [012-Regions.md](012-Regions.md)) while a parallel main-story thread introduces the reopening of travel to Vethmoor and the Concord Council's cautious response. Ends with the player's first crossing to Vethmoor.

### Act II — Fracture Lines *(Levels 20–40, Vethmoor)*
The player becomes entangled in Concord–Pact tension as both factions race to investigate ancient Ironpeak/Ashenclaw ruins uncovering pre-Sundering technology and corrupted energy. Introduces the Ashen Circle ([033-Factions.md](033-Factions.md)) as a guide figure.

### Act III — The Sunken Concord *(Levels 45–50, culminating in the launch raid)*
The trail leads to the drowned ruins of Aethercrest beneath the Shattered Cairns. The main story campaign culminates in the events leading into the [017-Raids.md](017-Raids.md) launch raid, where a fragment of Kaelgorath's influence must be confronted.

## Design Rules
* Main story quests are solo-completable but reference and reward the region's local questlines.
* Faction choice colors dialogue and framing but does not lock players out of the core critical path.
* Side stories ([038-Side-Stories.md](038-Side-Stories.md)) should never be required to understand the main story, only to enrich it.
