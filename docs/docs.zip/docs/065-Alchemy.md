# 65 — Alchemy

## Overview
Alchemy is a production profession that transforms herbs (gathered via [064-Herbalism.md](064-Herbalism.md)) into potions and other consumable effects ([057-Consumables.md](057-Consumables.md)).

## Core Loop
Learn a potion recipe → gather required herbs → brew at an alchemy station → produce a stack of potions for personal use or sale.

## Recipe Categories
* **Healing/Restoration Potions** — core sustain consumables.
* **Combat Potions** — temporary stat buffs for dungeons/raids.
* **Utility Potions** — situational effects (underwater breathing, fall damage reduction, temporary resistances).
* **Transmutation** — rare recipes converting one material into another, a modest but reliable Aurum-sink/source loop.

## Design Notes
Alchemy should have a small number of Best-in-Slot raid-prep potions gated behind rare/raid-drop herbs, giving max-level alchemists continued relevance rather than the profession maxing out in usefulness at max character level.
