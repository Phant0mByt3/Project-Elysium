# 87 — Seasons

## Overview
Seasons are the umbrella structure for time-limited content: PvP ranked resets ([085-Arenas.md](085-Arenas.md)), real-world-calendar-aligned celebrations, and rotating seasonal world events.

## Season Structure
Each season runs roughly 10–12 weeks, resetting Arena ratings and introducing a themed rotating world event alongside standard content (dungeons, raids, dailies).

## Launch Calendar (illustrative)

| Season Theme | Notes |
|---|---|
| **The Reclamation Festival** | Celebrates the reopening of Aurelia–Vethmoor travel; ties directly into the main story's premise ([037-Main-Story.md](037-Main-Story.md)). |
| **Emberfall** | Autumn-themed event centered on Ignareth and the Ember Deeps region. |
| **The Long Dusk** | Winter event tied to Nyxara, featuring increased Duskward-flavored world events. |
| **Dawnrise** | Spring event tied to Solthar and Aeloria, featuring Concord-flavored world events and the year's first major PvP season reset. |

## Design Rules
* Seasonal cosmetic rewards ([093-Cosmetics.md](093-Cosmetics.md)) should be time-limited to their season, encouraging participation, but should return in some form (recolor, achievement-based catch-up) in future years rather than being permanently lost — to be finalized as a live-service policy ahead of Phase 7 ([003-Roadmap.md](003-Roadmap.md)).
* Seasonal events should never gate core story or class content — only cosmetics, titles, and minor convenience rewards.
