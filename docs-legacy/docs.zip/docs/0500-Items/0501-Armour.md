# 0501 — Armour

## Armor Categories
* **Cloth** — lowest base armor, highest Intellect budget; Mage, Necromancer, Cleric.
* **Leather** — moderate armor and Agility budget; Rogue, Ranger, Druid.
* **Mail** — higher armor, balanced budget; Ranger (secondary), Druid (secondary).
* **Plate** — highest armor, Strength/Stamina focused; Warrior, Paladin.

## Slots
Head, Shoulders, Chest, Hands, Waist, Legs, Feet, Cloak, plus two Accessory slots covered in [0502-Accessories.md](0502-Accessories.md).

## Set Bonuses
Armor from the same dungeon or raid tier shares a themed visual set. Equipping multiple pieces from the same set grants a bonus effect (2-piece and 4-piece thresholds), reinforcing the value of running content repeatedly rather than mixing loot at random — see [0504-Loot-Tables.md](0504-Loot-Tables.md) for how sets are distributed.

## Progression
Armor item level scales through: quest rewards (early leveling) → dungeon drops (mid-level) → crafted gear ([0508-Crafting.md](0508-Crafting.md), tailoring/blacksmithing) → raid drops (endgame). This mirrors the leveling curve in [0305-Leveling.md](../0300-Characters/0305-Leveling.md).

## Visual Standards
Each armor class (Cloth/Leather/Mail/Plate) should be silhouette-distinct even at a distance, so a player's role is readable in group content without opening a character sheet — see [1300-Art-Style.md](../1300-Art/1300-Art-Style.md).
