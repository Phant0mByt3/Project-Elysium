# 0102 — Regions

Regions are the primary zone unit players experience — smaller than a continent, larger than a single city. Each region is scoped to a level band before any building begins, per [0002-Core-Pillars.md](../0000-Project/0002-Core-Pillars.md).

## Region Template

Every region should be documented with:
* **Continent & Level Range**
* **Theme / Biome**
* **Dominant Faction / Race Presence**
* **Key Locations** (cities, dungeons, landmarks)
* **Local Conflict** — the small-scale story driving quests in this region
* **Notable Enemies**

## Aurelia Regions

| Region | Level Range | Theme |
|---|---|---|
| The Southern Shires | 1–10 | Starting farmland, tutorial zone |
| Wildwood Reach | 8–16 | Overgrown forest, bandit activity |
| The Greywater Fens | 14–20 | Marshland, undead incursions |
| The Sunspire Hills | 18–25 | Rolling gold hills, Concord military presence |
| Solmere Capital District | Any | Hub region surrounding the capital |

## Vethmoor Regions

| Region | Level Range | Theme |
|---|---|---|
| Frostgate Approach | 24–30 | Mountain pass, contested border |
| The Ember Deeps | 28–36 | Volcanic underground mines |
| Ashenclaw Tundra | 34–42 | Orc clan territory, open PvP hotspots |
| The Ironpeak Holds | 38–46 | Dwarven fortress-cities |
| The Shattered Cairns | 44–50 | Endgame pre-raid zone, Sundering scarring |

Each region listed above is expanded into full design documents as world-building begins (see [0003-Roadmap.md](../0000-Project/0003-Roadmap.md), Phase 3). Cities within regions are detailed in [0103-Cities.md](0103-Cities.md); dungeons in [0106-Dungeons.md](0106-Dungeons.md).
