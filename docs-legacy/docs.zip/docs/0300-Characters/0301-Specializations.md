# 0301 — Specializations

## Overview
Each of the eight classes ([0300-Classes.md](0300-Classes.md)) offers two specializations, unlocked at level 10, that determine the class's primary role and reshape its talent tree ([0303-Talent-Trees.md](0303-Talent-Trees.md)).

## Specialization List

| Class | Spec A | Spec B |
|---|---|---|
| Warrior | Vanguard (Tank) | Berserker (Damage) |
| Paladin | Sentinel (Tank) | Lightbringer (Healer) |
| Rogue | Shadowblade (Damage) | Trickster (Damage, utility-focused) |
| Ranger | Marksman (Damage) | Beastmaster (Damage, pet-focused) |
| Mage | Frostweaver (Damage, control-focused) | Pyromancer (Damage, burst-focused) |
| Necromancer | Reaper (Damage) | Plaguebringer (Damage, DoT-focused) |
| Cleric | Warden (Healer) | Zealot (Damage/Healer hybrid) |
| Druid | Wildshaper (Damage/Tank) | Grovekeeper (Healer) |

## Design Rules
* Both specializations of a class should feel mechanically distinct, not just numerically different.
* Respeccing between specs should be freely available outside of combat, to encourage experimentation.
* No specialization should be a strict upgrade of the other — each should have distinct strengths documented as part of the ongoing balance process ([0309-Balance.md](0309-Balance.md)).

Full skill and talent breakdowns per specialization are covered in [0302-Skills.md](0302-Skills.md) and [0303-Talent-Trees.md](0303-Talent-Trees.md) as class design is finalized.
